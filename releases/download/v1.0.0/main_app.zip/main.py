
import tkinter as tk
from tkinter import messagebox

def main():
    root = tk.Tk()
    root.title("ST AI ONEUI")
    root.geometry("400x300")
    tk.Label(root, text="ST AI ONEUI 정상 실행", font=("Arial", 16)).pack(pady=40)
    tk.Button(root, text="종료", command=root.quit).pack()
    root.mainloop()

if __name__ == "__main__":
    main()
